# Nova Kingdom Rentals — Source of Truth

This file is the official business memory. Every agent must use this before making customer-facing decisions.

## Business identity

- Business name: Nova Kingdom Rentals
- Ownership entity: Baaz Global Inc.
- Base: Bridgewater, Nova Scotia
- Website: novakingdomrentals.com
- Email / e-transfer: booknovakingdom@gmail.com
- Service language: premium, clear, local, fun, royal, trustworthy
- Customer-facing sender: Nova Kingdom Rentals or Nova Kingdom Rentals Team
- Do not use the owner’s personal name in customer-facing drafts unless explicitly requested.

## Core offer

Nova Kingdom Rentals provides inflatable rentals, party rentals, lawn games, and event add-ons for birthdays, schools, daycares, community events, fundraisers, churches, and private parties.

## Delivery and travel

- First 15 km from Bridgewater are free unless a custom quote says otherwise.
- Travel after the free zone: $0.72/km.
- Always ask for the event address before a final quote.
- For distant small bookings, flag low-margin risk and consider minimum order or package upsell.

## Payment rules

- Standard deposit: 30% to secure booking.
- Remaining balance: due at delivery/setup unless another written arrangement is approved.
- Booking is not confirmed until deposit is received.
- E-transfer accepted at booknovakingdom@gmail.com.
- Schools/organizations may request invoice and cheque payment; still flag that date is secured according to approved payment terms.
- Credit card/bank processing fee: 5% if used, unless owner waives it.
- HST: do not charge unless registered or required. If asked: “HST is not charged at this time unless applicable/required.” If the business becomes registered/required to collect, use the current Nova Scotia HST rate, which is 14% as of April 1, 2025, unless CRA/NS rules change.

## Standard private/backyard 8-hour individual pricing

| Item | Standard price | Duration |
|---|---:|---|
| Crown Rush 42 | $450 | 8 hours |
| Crown Quest | $240 | 8 hours |
| Crown Cascade | $260 | 8 hours |
| Crown Climber | $280 | 8 hours |
| Crown Dino Combo | $210 | 8 hours |
| Crown Island Combo | $310 | 8 hours |
| Crown Axe Challenge | $180 | 8 hours |
| Crown Kick Darts | $160 | 8 hours |

## Current / near-term inventory note

Current available lineup has included Crown Island Combo, Axe Thrower/Crown Axe Challenge, Football Darts/Crown Kick Darts, and Lawn Games. Other larger units were planned for June arrival. Before promising any unit, verify the current inventory and arrival status.

## Branded product names and positioning

| Product | Tagline / positioning |
|---|---|
| Crown Rush 42 | Conquer the Course Like Royalty — 42 ft obstacle + water slide combo |
| Crown Quest | Conquer Every Challenge Like Royalty — obstacle course |
| Crown Cascade | Make a Splash Like Royalty — water slide |
| Crown Climber | Reach the Top Like Royalty — climbing wall |
| Crown Dino Combo | Bounce Like a Dino, Rule Like a King |
| Crown Island Combo | Island Fun Like Royalty — bounce + slide + pool/ball pit option |
| Crown Axe Challenge | inflatable axe throwing challenge |
| Crown Kick Darts | football darts challenge |

## 6-hour event/package pricing

| Package | Price | Regular value | Savings | Includes |
|---|---:|---:|---:|---|
| Cascade Starter | $320 | $370 | $50 | Crown Cascade + 5 Lawn Games |
| Dino Dash | $310 | $360 | $50 | Crown Dino Combo + Crown Kick Darts |
| Island Splash | $370 | $420 | $50 | Crown Island Combo + 5 Lawn Games |
| Quest & Games | $449 | $530 | $81 | Crown Quest + Crown Axe Challenge + 5 Lawn Games |
| Dino Party Plus | $549 | $681 | $132 | Crown Dino Combo + Crown Kick Darts + Crown Axe Challenge + 5 Lawn Games |
| Island Royale | $649 | $781 | $132 | Crown Island Combo + Crown Kick Darts + Crown Axe Challenge + 5 Lawn Games |
| Royal All-Star | $849 | $910 | $61 | Crown Rush 42 + Crown Axe Challenge + Crown Kick Darts + 5 Lawn Games |
| Kingdom Deluxe | $1,099 | $1,220 | $121 | Crown Rush 42 + Crown Island Combo + Crown Axe Challenge + Crown Kick Darts + 5 Lawn Games |
| Ultimate Kingdom | $1,499 | $1,710 | $211 | Crown Rush 42 + Crown Climber + Crown Island Combo + Crown Dino Combo + Crown Axe Challenge + Crown Kick Darts + 5 Lawn Games |

## Lawn games

Known lawn games include Cornhole, Giant Connect 4, Giant Jenga, Ladder Toss, Ring Toss, Badminton, Tug of War, Tic Tac Toe, Washer Toss, Spikeball, Bocce Ball, and Croquet.

Pricing logic:

- 5 lawn games standalone: $150.
- If a package already includes 5 lawn games, offer upgrade to all 12 lawn games for +$100 extra.
- If a package does not include lawn games, offer all 12 lawn games for $250.
- Do not invent individual game pricing without approval.

## Staffing and attendants

- Attendant/supervisor rate: $30/hour per person unless owner changes it.
- Inflatables require responsible adult supervision.
- Lawn games, Crown Axe Challenge, and Crown Kick Darts do not normally require dedicated attendants, but attendants can be arranged if requested or recommended for public events.
- For large school/public events, recommend or require attendants based on risk.

## Safety and setup rules

- Indoor gym setups require sandbags because stakes cannot be used indoors.
- Weather, wind, thunder/lightning, surface, water, power, and supervision must be checked.
- Customer must provide safe site access, suitable surface, required power/water, and adult supervision unless staff are booked.
- Water should be turned off at least 1 hour before pickup for wet units.
- Foam can create slippery conditions around inflatables; flag this as a serious safety concern and require owner review.
- Never operate or recommend operation if safety conditions are not met.

## Weather / reschedule rules

- Customer should monitor weather and give written notice at least 12 hours before event for weather-related reschedule request.
- Deposit is normally non-refundable but may transfer to one rescheduled date within 90 days if policy requirements are met.
- Within 24 hours or after setup, refund/reschedule options are limited and require policy/owner review.
- Company may shut down or refuse operation for safety.

## Customer trust rules

Nova Kingdom Rentals is a newer business. If asked for references, be honest:

- Say the business launched in May 2026 and is building its review base.
- Offer proof of insurance/registration if available, equipment photos, invoice, agreement, and safety/setup process.
- Do not fake references or exaggerate history.

## Communication tone

- Human, short, clear, not robotic.
- Customer messages should usually be shorter than internal notes.
- Avoid overexplaining unless the customer needs institutional detail.
- For schools and organizations, use professional email style.
- For Facebook/Instagram leads, use short friendly replies.

## Insurance and trust documents

- Standard insurance reference: $2M liability coverage.
- Broker reference: Broker Link 1408.
- Renewal / key insurance date: April 28.
- When customers, schools, municipalities, or event organizers ask for insurance, offer proof/certificate where available and route through Documents & Legal Manager.
- Do not claim a specific certificate has been issued for an event until the document exists and is verified.

## Review link

- Google Review link: https://g.page/r/CZXOs7GUjxR5EBI/review
- Use this in review-request templates after completed events.

## Short-event pricing

- 3-hour, 4-hour, 5-hour, and other shortened event pricing is [TO BE CONFIRMED] unless a specific approved quote exists.
- Do not invent short-event pricing. Draft options and flag owner approval required.

## Approval required

Owner approval required for:

- Refunds
- Discounts over 10%
- Free delivery outside normal range
- Safety exceptions
- Public events with unusual risk
- Injury/incident complaints
- Legal threats
- Insurance claims
- Changing official pricing or contract terms
- Promising unavailable or not-yet-arrived units
- Any booking below minimum profitable margin
